class City {
    constructor() {

    }

}


module.exports = City;