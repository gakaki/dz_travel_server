class Visitor {
    constructor() {

    }

}


module.exports = Visitor;