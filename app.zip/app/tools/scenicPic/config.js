module.exports = {
    picBaseDir: '../H5/arts//小程序/点亮足迹/切图',//jingdian图片资源父路径
    picDirName: 'jingdian',
    outFile: './景点图配置统计结果.txt'
}