const travelConfig = require("../../../sheets/travel");
const ScenicPos = require("../../../sheets/scenicpos");
const moment = require("moment");
const holidayCn = require('holiday.cn').default;


const utils = require("../../utils/utils");

console.log(Math.sqrt(25));