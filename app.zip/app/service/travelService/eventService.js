//积分相关数据逻辑
const Service = require('egg').Service;
const sheets = require('../../../sheets/travel');
const apis = require('../../../apis/travel');

class EventService extends Service {
    async fetchResult( uid , cid ) {
        
    }
}

module.exports = EventService;